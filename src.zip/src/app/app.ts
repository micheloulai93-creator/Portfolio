import { AfterViewInit, Component, inject } from '@angular/core';
import { Navbar } from './components/navbar/navbar';
import { Header } from './components/header/header';
import { About } from './components/about/about';
import { Stats } from './components/stats/stats';
import { Skills } from './components/skills/skills';
import { Portfolio } from './components/portfolio/portfolio';
import { Experiences } from './components/experiences/experiences';
import { Testimonials } from './components/testimonials/testimonials';
import { Blog } from './components/blog/blog';
import { Contact } from './components/contact/contact';
import { Footer } from './components/footer/footer';
import { ScriptLoader } from './services/script-loader';

@Component({
  selector: 'app-root',
  imports: [
    Navbar,
    Header,
    About,
    Stats,
    Skills,
    Portfolio,
    Experiences,
    Testimonials,
    Blog,
    Contact,
    Footer
  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App implements AfterViewInit {
  title = 'IIT-Portfolio';
  private loader = inject(ScriptLoader);

  ngAfterViewInit() {
    this.loader.loadTemplateScripts();
  }
}