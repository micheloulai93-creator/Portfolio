import { Component, HostListener, signal } from '@angular/core';

interface Project {
  title: string;
  category: string;
  images: string[];
  url?: string;
}

// Génère les chemins 1.png, 2.png ... d'un dossier : gallery('ca2mi', 8)
const gallery = (folder: string, count: number, ext = 'png'): string[] =>
  Array.from({ length: count }, (_, i) => `assets/images/projects/${folder}/${i + 1}.${ext}`);

@Component({
  selector: 'app-portfolio',
  imports: [],
  templateUrl: './portfolio.html',
  styleUrl: './portfolio.scss'
})
export class Portfolio {
  githubUrl = 'https://github.com/micheloulai93-creator';

  projects: Project[] = [
    {
      title: 'CA2MI',
      category: "Gestion d'entreprise · React, Django, PostgreSQL",
      images: gallery('ca2mi', 4),
      // Avec vos captures : images: gallery('ca2mi', 8),
    },
    {
      title: 'Logiciel comptable',
      category: 'Projet universitaire · Logiciel pour PME',
      images: gallery('compta', 4),
      // Avec vos captures : images: gallery('compta', 6),
    },
    {
      title: 'Portfolio personnel',
      category: 'Angular · Bootstrap',
      images: ['assets/images/projects/portfolio.svg'],
      // À remplacer par le lien du dépôt GitHub de ce portfolio
      url: 'https://github.com/micheloulai93-creator',
    },
  ];

  // Galerie (lightbox)
  openProject = signal<Project | null>(null);
  index = signal(0);

  onCard(project: Project, event: Event): void {
    if (project.url) return; // lien externe : le navigateur s'en charge
    event.preventDefault();
    this.openProject.set(project);
    this.index.set(0);
    document.body.style.overflow = 'hidden';
  }

  close(): void {
    this.openProject.set(null);
    document.body.style.overflow = '';
  }

  next(): void {
    const p = this.openProject();
    if (!p) return;
    this.index.set((this.index() + 1) % p.images.length);
  }

  prev(): void {
    const p = this.openProject();
    if (!p) return;
    this.index.set((this.index() - 1 + p.images.length) % p.images.length);
  }

  @HostListener('document:keydown', ['$event'])
  onKey(event: KeyboardEvent): void {
    if (!this.openProject()) return;
    if (event.key === 'Escape') this.close();
    else if (event.key === 'ArrowRight') this.next();
    else if (event.key === 'ArrowLeft') this.prev();
  }
}