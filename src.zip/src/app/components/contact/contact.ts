import { Component } from '@angular/core';

interface Info {
  icon: string;
  title: string;
  text: string;
  href?: string;
}

@Component({
  selector: 'app-contact',
  imports: [],
  templateUrl: './contact.html',
  styleUrl: './contact.scss'
})
export class Contact {
  // L'adresse est écrite ici (et non dans le HTML) : le @ n'y pose aucun problème
  email = 'micheloulai93@gmail.com';

  infos: Info[] = [
    {
      icon: 'mbri-letter',
      title: 'E-mail',
      text: this.email,
      href: 'mailto:' + this.email,
    },
    {
      icon: 'mbri-mobile',
      title: 'Téléphone',
      text: '01 73 46 67 22',
      href: 'tel:+2250173466722',
    },
    {
      icon: 'mbri-map-pin',
      title: 'Adresse',
      text: "Grand-Bassam, Côte d'Ivoire",
    },
  ];

  // Sans serveur : le formulaire ouvre l'application e-mail avec le message pré-rempli
  send(event: Event, name: string, from: string, subject: string, message: string): void {
    event.preventDefault();
    const body = `${message}\n\n${name} (${from})`;
    window.location.href =
      `mailto:${this.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  }
}